﻿using System;
namespace HelloWorld {
    class Hello {
        static void Main(string[] args) {
            Console.Write("Hello ");
            Console.WriteLine(Console.ReadLine());
        }
    }
}