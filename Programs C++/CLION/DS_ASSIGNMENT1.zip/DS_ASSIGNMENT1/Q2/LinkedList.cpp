#include "LinkedList.h"

LinkedList::LinkedList():head(nullptr){}

LinkedList::~LinkedList(){}

void LinkedList::insert(int value){

    //empty case

    if(head == nullptr){
        head = new Node(value);
        head->next=nullptr;
    }
    else if(head->next== nullptr){
        Node *temp = new Node(value);
        head->next = temp;
    }
    else{

        //non empty case
        Node *current = head;
        while(current->next->next != nullptr){
            current = current->next;
        }
        Node *temp = new Node(value,current);
        temp->next = current->next;
        current->next = temp;
        temp->next->next=nullptr;
    }

}

std::ostream& operator <<(std::ostream& ostr, const LinkedList& rhs){
    Node *current = rhs.head;
    while(current != nullptr){
        std :: cout<< current->data <<" ";
        current = current->next;
    }
    return ostr;
}

void LinkedList::mergelists(Node *v){
    Node *current = head;
    while(current->next!=nullptr){
        current = current->next;
    }
    current->next = v;
}

void LinkedList::mergeList(const LinkedList &from) {
    Node *current = head;
    while (current -> next != nullptr)
        current = current->next;

}


void LinkedList::del(){

    //empty list

    if(head==nullptr){

        throw std::out_of_range("Tried to delete empty linked list");
    }

    if(head->next==nullptr){

        std :: cout << "Deleted" << head->data;
        delete head;
        head = nullptr;
    }
    else{
        Node *current = head;
        current = current->next;
        head->next=current->next;
        std :: cout << "Deleted " << current->data;
        delete(current);

    }
}


Node* LinkedList::gethead(){
    return head;
}

void LinkedList::compress(){
    Node *start = head;
    Node *current = head;
    while(start!=nullptr){
        int x = start->data;

        while(current->next!=nullptr){

            if(current->next->data==x){

                Node*temp = current->next;
                current->next = current->next->next;
                delete(temp);
            }
            else
                current = current->next;
        }
        start = start->next;
        current = start;
    }

}








