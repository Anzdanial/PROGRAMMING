class Node{
public:
    Node* next;
    int data;
    Node(int value, Node* next = nullptr);
};