#include "Node.h"
Node::Node(int value, Node *next):data(value),next(next){
}