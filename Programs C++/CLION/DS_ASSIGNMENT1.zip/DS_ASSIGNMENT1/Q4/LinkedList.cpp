#include "LinkedList.h"


LinkedList::LinkedList()
        :head(nullptr),end(nullptr)
{

}

LinkedList::~LinkedList(){

}

void LinkedList::insert(int value){

    //empty case

    if(head == nullptr){
        head = new Node(value);
        head->next = head;
        end = head;
    }
    else{

        Node* newNode = new Node(value);
        end->next = newNode;
        newNode->next = head;
        end = newNode;

    }
}

std::ostream& operator <<(std::ostream& ostr, const LinkedList& rhs){


    Node *current = rhs.head;
    while(current != rhs.end){
        std :: cout<< current->data <<" ";
        current = current->next;
    }



    return ostr;
}

LinkedList LinkedList::convert(int arr[]){

    LinkedList a;


    for(int i=0;i<=sizeof(arr[0]);i++){
        a.insert(arr[i]);
    }

    return a;


}


















