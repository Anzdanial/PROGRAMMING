#include <iostream>
#include "LinkedList.h"
using namespace std;

template <class T>
struct ListNode{
    T data;
    Node* next;
};



int main(){
    int arr[5] = {1,2,4,5};
    LinkedList a = a.convert(arr);

    std :: cout<< a << std::endl;

    return 0;
}