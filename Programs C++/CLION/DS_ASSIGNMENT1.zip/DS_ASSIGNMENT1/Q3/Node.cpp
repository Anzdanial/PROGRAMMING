#include "Node.h"

Node::Node(int value, Node *next, Node *prev)
        :data(value),next(next),prev(prev)
{
    //no boy
}