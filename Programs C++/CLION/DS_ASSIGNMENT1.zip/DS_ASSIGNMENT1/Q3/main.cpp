
#include <iostream>
#include "LinkedList.h"

using namespace std;

int main(){

    LinkedList a;
    a.insert(7);
    a.insert(6);
    a.insert(6);
    a.swap(7, 6);
    std :: cout<< a << std::endl;

    return 0;
}