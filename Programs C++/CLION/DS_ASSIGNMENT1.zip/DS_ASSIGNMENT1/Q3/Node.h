class Node{
public:
    Node* next;
    Node* prev;
    int data;
    Node(int value,Node* next = nullptr,Node*prev = nullptr);
};