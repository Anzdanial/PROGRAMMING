#include "LinkedList.h"


LinkedList::LinkedList():head(nullptr){}

LinkedList::~LinkedList(){}

void LinkedList::insert(int value){

    //empty case

    if(head == nullptr){
        head = new Node(value);
        head->next=nullptr;
    }
    else{

        Node *current = head;
        while(current->next!=nullptr){
            current = current->next;
        }
        current->next=new Node(value);
        current->next->prev=current;
        current->next->next=nullptr;

    }

}

std::ostream& operator <<(std::ostream& ostr, const LinkedList& rhs){
    Node *current = rhs.head;
    while(current != nullptr){
        std :: cout<< current->data <<" ";
        current = current->next;
    }

    return ostr;
}

void LinkedList::swap(int x,int y){

    // Search for x (keep track of prevX and CurrX)
    Node *X = nullptr, *curr1 = head;
    while (curr1 && curr1->data != x) {
        X = curr1;
        curr1 = curr1->next;
    }

    // Search for y (keep track of prevY and CurrY
    Node *Y = nullptr, *curr2 = head;
    while (curr2 && curr2->data != y) {
        Y = curr2;
        curr2 = curr2->next;
    }

    // If either x or y is not present, nothing to do
    if (curr1 == nullptr || curr2 == nullptr)
        return;

    curr1->prev = Y;
    Y->next->next->prev = curr1;
    curr1->next = Y->next->next;
    Y->next = curr1;

    curr2->prev = X;
    X->next->next->prev = curr2;
    curr2->next = X->next->next;
    X->next = curr2;
}
